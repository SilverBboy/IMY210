var cors = require('cors');
var routes = (app, fs, corsOperations) => {
	data_file="data.json";

	app.options('*', cors(corsOperations));

	app.get('/', function (req, res){
		res.send('"Well hello there" - Obi-Wan Kenobi');
	})

	app.get('/data', function (req, res){
		fs.readFile(data_file, (error, rdata) => {
			if (error)
				throw error;
			var readout = JSON.parse(rdata);
			res.send(readout);
		})
	})

	app.get('/data/:id', function (req, res){
		fs.readFile(data_file, (error, rdata) => {
			if (error)
				throw error;
			var readout = JSON.parse(rdata);
			var number = readout.find((rdata_obj) => getId(rdata_obj, req.params.id));
			if (number == undefined){
				res.send('Object not found');
			}
			res.send(number);
		})
	});

	function getId(rdata_obj, passed_id){
		return passed_id == rdata_obj.id
	}

	app.post('/data', cors(corsOperations), (request, respond) => {
		fs.readFile(data_file, (error, rdata) => {
			if (error)
				throw error;
			var tmp = JSON.parse(rdata);
			var newindex = Object.keys(tmp).length;
			var tmpObject = request.body;

			tmp[newindex] = tmpObject;
			console.log(tmp);

			fs.writeFile(data_file, JSON.stringify(tmp), (error, rdata) => {
			 	if (error)
			 		throw error;
			 	respond.send(tmpObject);
			 })
		})
	});

	app.put('/data/:id', cors(corsOperations), (req, res) => {
		fs.readFile(data_file, (error, rdata) => {
			if (error)
				throw error;
			var readout = JSON.parse(rdata);
			var number = readout.find((rdata_obj) => getId(rdata_obj, req.params.id));
			number.name = req.body.name;
			number.price = req.body.price;

			fs.writeFile(data_file, JSON.stringify(readout), (error, rdata) => {
				if (error)
					throw error;
				res.send(number);
			})
		})
	});

	app.delete('/data/:id', cors(corsOperations), (req, res) => {
		fs.readFile(data_file, (error, rdata) => {
			if (error)
				throw error;
			var readout = JSON.parse(rdata);
			var getind = readout.findIndex((rdata_obj) => getId(rdata_obj, req.params.id));
			if (getind === -1){
				throw error;
			}
			readout.splice(getind, 1);

			fs.writeFile(data_file, JSON.stringify(readout), (error, rdata) => {
				if (error)
					throw error;
				res.send(readout);
			})
		})
	});
}

module.exports = routes;