var express = require('express');
var bodyParser = require('body-parser');
var fs = require('fs');

var app = express();
var port = process.env.PORT || 3000;
var cors = require('cors');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.use(cors(corsOperations));

var corsOperations = {
	origin: "*",
	methods: "GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS",
};

var routes = require('./routes.js')(app,fs, corsOperations);

app.get('/', function (req, res){
	res.send("Are you my morning coffee? Because you're hot.");
});

app.listen(port);
console.log("You're vibing on port: " + port);